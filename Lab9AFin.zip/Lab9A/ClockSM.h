#include "ClockBasics.h"
#include "ButtonDebounce.h"
#include "EncoderMonitor.h"
// set up states for clock
enum ClockStates {CLOCK_RUNNING, CLOCK_SET_HOURS,
                  CLOCK_SET_MINUTES, CLOCK_SET_SECONDS};

ClockStates clockState = CLOCK_RUNNING;

// Funcion reads button presses, resets clock
void SettingClock(int Button, int UpDown) {
    //input based on state
    switch(clockState) {
        case CLOCK_RUNNING:
            if (Button) { // reset timer
                clockState = CLOCK_SET_HOURS; // set hours
                CLK_HOURS = 0;
                CLK_Minutes = 0;
                CLK_Seconds = 0;
            }
            break;
        case CLOCK_SET_HOURS:
            if (Button) {
                clockState = CLOCK_SET_MINUTES; // move to minutes
            }
            else {
                CLK_HOURS += UpDown; // adjust hours
                if (CLK_HOURS > 23) {
                    CLK_HOURS = 0;
                }
                if (CLK_HOURS < 0) { // wrap hours
                    CLK_HOURS = 23;
                }
            }
            break;
        case CLOCK_SET_MINUTES:
            if (Button) {
                clockState = CLOCK_SET_SECONDS;
            } else {
                CLK_Minutes += UpDown; // adjust minutes
                if (CLK_Minutes > 59) {
                    CLK_Minutes = 0;
                }
                if (CLK_Minutes < 0) {
                    CLK_Minutes = 59;
                }
            }
            break;
        case CLOCK_SET_SECONDS:
            if (Button) {
                clockState = CLOCK_RUNNING;
            } else {
                CLK_Seconds += UpDown;
                if (CLK_Seconds > 59) {
                    CLK_Seconds = 0;
                }
                if (CLK_Seconds < 0) {
                    CLK_Seconds = 59;
                }
            }
            break;
    } // end of clock mode
} // end of ClockSM
