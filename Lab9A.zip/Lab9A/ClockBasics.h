#ifndef ClockBasics_H
#define ClockBasics_H

#include <LiquidCrystal.h>
LiquidCrystal LcdDriver(A5,A4, 5, 6, 7, 8);

void setLCD() {
  LcdDriver.begin(16,2);
  LcdDriver.clear();
}
// Variable used as clock settings 
int CLK_Hours, CLK_Minutes, CLK_Seconds;

/*
    This function is to be called every second
    to update the clock represented by the global
    variables Hours, Minutes, Seconds
*/

void UpdateClock() {
    // Check Seconds not at wrap point
    if (CLK_Seconds < 59) {
        CLK_Seconds++; // increment seconds
    }
    else {
        CLK_Seconds = 0; // reset seconds
        if (CLK_Minutes < 59) {
            CLK_Minutes++;
        }
        else {
            CLK_Minutes = 0;
            if (CLK_Hours < 23) {
            CLK_Hours++;
        }
        else {
            CLK_Hours = 0; // reset 
        } // end CLK_Hours
        } // End of Minutes test
    } // End of Seconds test
} // end of UpdateClock

// Send Hours, Minutes and Seconds to a display
void SendClock() {
  LcdDriver.begin(16,2);
    LcdDriver.print(" ");
    // check if leading zero needs to be sent
    if (CLK_Hours < 10) {
        LcdDriver.print("0");
    }
    LcdDriver.print(CLK_Hours); // then send hours 
    LcdDriver.print(":"); // seperator
    // check for leading zero on minutes
    if (CLK_Minutes < 10) {
        LcdDriver.print("0");
    }
    LcdDriver.print(CLK_Minutes); // send minutes
    LcdDriver.print(":"); 
    if (CLK_Seconds < 10) {
        LcdDriver.print("0");
    }
    LcdDriver.print(CLK_Seconds);
} // end SendClock()



#endif
