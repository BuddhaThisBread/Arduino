enum buttonStates {buttonStart, buttonIdle, buttonWait, buttonHigh, buttonLow} buttonState;
unsigned long buttonTime;


void buttonInitialize() { // set pin, buttonState to buttonStart
  pinMode(4, INPUT);
  buttonState = buttonStart;
} // end of button initialize

int buttonNextState(int pressed) {
  switch (buttonState) {
    case (buttonStart): // initialzie program
      buttonState = buttonIdle;
    case (buttonIdle): // checks if button is pressed, goes to next state if so
      if (pressed == LOW) {
        buttonTime = millis();
        buttonState = buttonWait;
        digitalWrite(13, HIGH);
      }
      break;
    case (buttonWait):
      if (pressed == HIGH) {
        buttonState = buttonIdle;
        digitalWrite(13, LOW);
      } else if (millis() - buttonTime >= 5) {
        buttonState = buttonLow;
        digitalWrite(13, LOW);
        return 1;
      }
    case (buttonLow):
      if (pressed == HIGH) {
        buttonState = buttonIdle;
        if (millis() - buttonTime > 500) {
          buttonTime += 500;
          return 3;
        }
        return 2;
      }
    default:
      break;
  }
  return 0;
}
