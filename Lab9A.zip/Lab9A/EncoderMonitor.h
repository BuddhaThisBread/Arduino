volatile int encoderPostion;

void EncoderMonitorA() {
  if (digitalRead(2) == digitalRead(3)) {
    encoderPostion++;
  } else {
    encoderPostion--;
  }
}

void EncoderMonitorB() {
  if (digitalRead(2) == digitalRead(3)) {
    encoderPostion--;
  } else {
    encoderPostion++;
  }
}

void EncoderInitialize() {
  pinMode(2,INPUT);
  pinMode(3, INPUT);
  attachInterrupt(digitalPinToInterrupt(2), EncoderMonitorA, CHANGE);
  attachInterrupt(digitalPinToInterrupt(3), EncoderMonitorB, CHANGE);
}
