#include "ButtonDebounce.h"
#include "EncoderMonitor.h"
// set up states for clock
enum ClockStates {CLOCK_RUNNING, CLOCK_SET_HOURS,
                  CLOCK_SET_MINUTES, CLOCK_SET_SECONDS
                 };

ClockStates clockState = CLOCK_RUNNING;

#include "ClockBasics.h"

// Funcion reads button presses, resets clock
void MoveClockState() {
  switch (clockState) {
    case CLOCK_RUNNING: // main detects long press
      clockState = CLOCK_SET_HOURS; // moves to set clock hours
      break;
    case CLOCK_SET_HOURS:
      clockState = CLOCK_SET_MINUTES; // moves from setting hours to minutes
      break;
    case CLOCK_SET_MINUTES:
      clockState = CLOCK_SET_SECONDS;
      break;
    case CLOCK_SET_SECONDS: // loop back to CLOCK_RUNNING state
      clockState = CLOCK_RUNNING;
    default: // reset to CLOCK_RUNNING
      clockState = CLOCK_RUNNING;
  }
  LcdDriver.cursor();
  LcdDriver.blink();
}

void IncreaseClock() { // called after MoveClockState()
  switch (clockState) { // increments after short presses
    case CLOCK_RUNNING:
      break;
    case CLOCK_SET_HOURS: // on short press, increase
      CLK_Hours++;        // CLK_Hours by 1
      if (CLK_Hours > 23) { // loop from 23 to 0
        CLK_Hours = 0;
      }
      break;
    case CLOCK_SET_MINUTES: // same as CLOCK_SET_HOURS
      CLK_Minutes++;
      if (CLK_Minutes > 59) {
        CLK_Minutes = 0;
      }
      break;
    case CLOCK_SET_SECONDS:
      CLK_Seconds++;
      if (CLK_Seconds > 59) {
        CLK_Seconds = 0;
      }
      break;
    default:
      break;
  }
}
